bikeshare_data.py readme.txt

The following sources were used to complete this assignment

- Udacity Training exercises
- Stack Overflow (https://stackoverflow.com) was used regular for help on syntax and different solutions to problems
- Python Documentation (https://docs.python.org)
- Pandas Documentation (https://pandas.pydata.org)
- General google search leading to numerous websites