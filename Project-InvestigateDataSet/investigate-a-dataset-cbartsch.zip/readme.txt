investigate-a-dataset-cbartsch.ipynb readme.txt

The following sources were used to complete this assignment

- Udacity Training exercises
- Stack Overflow (https://stackoverflow.com) was used regularly for help on syntax and different solutions to problems
- Python Documentation (https://docs.python.org)
- Pandas Documentation (https://pandas.pydata.org)
- MatPlotLib Documentation (https://matplotlib.org/contents.html)
- Seaborn Documentation (https://seaborn.pydata.org/)
- NumPy Documentation (https://docs.scipy.org/)
- General google search leading to numerous websites